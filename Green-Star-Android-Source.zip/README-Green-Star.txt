Green Star Android source upload

Upload this ZIP file to the ROOT of your GitHub repository (not inside a folder).
The repository already contains the Capacitor configuration and GitHub Actions workflow.
After uploading/committing this ZIP, open Actions > Build Green Star APK.
When the run succeeds, download the Green-Star-APK artifact and extract app-debug.apk.

The HTML viewport is set to 1024px so the Android WebView uses the desktop layout.
